let config_host = "https://fanqienovel.com"
let config_host2 = ""

if (typeof host !== "undefined") {
    config_host2 = host
}

    
let replaceCover = (u) => {
    if (u.startsWith("https://")) u = u.substring(8)
    else u = u.substring(7)
    let uArr = u.split("/")
    uArr[0] = "https://i0.wp.com/p6-novel.byteimg.com/origin"
    let uArr2 = []
    uArr.forEach((x) => {
        if (!x.includes("?") && !x.includes("~")) uArr2.push(x)
        else uArr2.push(x.split("~")[0])
    })
    u = uArr2.join("/")
    return u
}

const config = {
    baseUrl: "http://127.0.0.1:5005/proxy",
    install_id: "4427064614339001",
    server_device_id: "4427064614334905",
    aid: "1967",
    update_version_code: "62532",
    REG_KEY: "ac25c67ddd8f38c1b37a2348828e222e"
};
