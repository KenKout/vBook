load('config.js');
load('crypto.js');

const REG_KEY = "ac25c67ddd8f38c1b37a2348828e222e";
const INSTALL_ID = "4427064614339001";
const SERVER_DEVICE_ID = "4427064614334905";
const AID = "1967";
const UPDATE_VERSION_CODE = "62532";

function getRegisterKey() {
    let crypto = new CryptoJS.AES.CBC(REG_KEY);
    let serverDeviceId = parseInt(SERVER_DEVICE_ID);
    let strVal = "0";
    
    // Combine server device ID and string value
    let combined = new ArrayBuffer(16);
    let view = new DataView(combined);
    view.setInt32(0, serverDeviceId, true);
    view.setInt32(8, parseInt(strVal), true);
    
    // Generate random IV
    let iv = CryptoJS.lib.WordArray.random(16);
    
    // Encrypt data
    let encrypted = crypto.encrypt(combined, iv);
    let content = iv.concat(encrypted);
    let base64Content = CryptoJS.enc.Base64.stringify(content);
    
    // Make request to get register key
    let url = `https://api5-normal-sinfonlineb.fqnovel.com/reading/crypt/registerkey?aid=${AID}`;
    let response = fetch(url, {
        method: 'POST',
        headers: {
            'Cookie': `install_id=${INSTALL_ID}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            content: base64Content,
            keyver: 1
        })
    });
    
    if (response.ok) {
        let json = response.json();
        let keyStr = json.data.key;
        let decodedKey = CryptoJS.enc.Base64.parse(keyStr);
        let decryptedKey = crypto.decrypt(decodedKey);
        return decryptedKey.toString();
    }
    return null;
}

function execute(url) {
    const regex = /(?:item_id=|\/)(\d+)$/;
    let chapId = url.match(regex)[1];
    
    // Get chapter content
    let apiUrl = `https://api5-normal-sinfonlineb.fqnovel.com/reading/reader/batch_full/v?item_ids=${chapId}&req_type=1&aid=${AID}&update_version_code=${UPDATE_VERSION_CODE}`;
    let response = fetch(apiUrl, {
        headers: {
            'Cookie': `install_id=${INSTALL_ID}`
        }
    });
    
    if (response.ok) {
        let json = response.json();
        let key = getRegisterKey();
        let crypto = new CryptoJS.AES.CBC(key);
        
        let content = json.data[chapId].content;
        let decodedContent = CryptoJS.enc.Base64.parse(content);
        let decryptedContent = crypto.decrypt(decodedContent);
        
        // Decompress gzip content
        let decompressed = pako.inflate(decryptedContent, {to: 'string'});
        
        // Clean up content
        let cleanContent = decompressed
            .replace(/<p>/g, '')
            .replace(/<\/p>/g, '\n')
            .replace(/<header><\/header><article>/, '')
            .replace(/<\/article><footer><\/footer>/, '')
            .replace(/\n/g, '<br><br>');
            
        return Response.success(cleanContent);
    }
    
    return Response.error("Failed to fetch chapter");
}